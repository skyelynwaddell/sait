	// pointer to button
	var btnPtr = document.getElementById("myButton");
	
	// pointer to div
	var divPtr = document.getElementById("output");
	
	// variable for fileSize
	var fileCount = 1;
function getData() {	
	
	// XMLHttpRequest is a built in object to request data from server
	// This object can be used to receive data from and send data to the server
	var dataRequest = new XMLHttpRequest();   

	// Sending a request to the server open() and send()
	// open() specifies the request type
	//send() will send the request
	dataRequest.open('GET','http://localhost:8080/phpcourse/Day14/customer'+fileCount+'.json');
	dataRequest.onload = function(){
	var myData = dataRequest.responseText  //get the response data as string
	
	//console.log(myData);  // show all data received from server
	//Received data is string not JSON Data
	console.log(myData[0]);
	
	// To interpret these data as JSON data use JSON.parse() that is built in all browsers
	var myJSONData = JSON.parse(myData);
	console.log(myJSONData);
	console.log(myJSONData[0]);
	
	// Loading Data to Output DIV
	var JSONStr = "";
	for(i=0;i<myJSONData.length;i++){
		JSONStr += "<p>" + myJSONData[i].name + " is a "+ myJSONData[i].age + " Years old.</p>"
				+ "<p> Incompleted Projects: </p>"	
		for (j = 0; j<myJSONData[i].project.completed.length;j++){
			JSONStr += myJSONData[i].project.incompleted[j]+" ";
		}
		JSONStr += "<hr>";
	} 
	divPtr.innerHTML += JSONStr;
	
};
	dataRequest.send();
	fileCount++;
	if (fileCount > 2){
	btnPtr.innerHTML = "No More Files to Load";
	btnPtr.disabled=true;
	//btnPtr.style.visibility="hidden";
	}
}