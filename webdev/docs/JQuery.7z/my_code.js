/* JQUERY Example 1 */
$(document).ready(function()
{
	$("p").hide();		// to display use show()
	$("h1").click(function()
	{
	  $(this).next().slideToggle(300);
	  $(this).next().css("color","blue");
	  
	});
	/*
	$("button").mouseenter(function()   // mouseenter same as mouseover
	{
	  $ (this).css("background-color","blue");
	  $ (this).css("color","white");
	  
	});
	
	$("button").mouseleave(function()   // mouseleave same as mouseout
	{
	  $ (this).css("background-color","green");
	  $ (this).css("color","white");
	  
	});
	*/
	$("button").hover(function()   // use the following to replace mouseenter and mouseleave
	{
	  $ (this).css("background-color","blue");
	  $ (this).css("color","white");
	},	
	function()   // mouseleave same as mouseover
	{
	  $ (this).css("background-color","green");
	  $ (this).css("color","white");
	});
	
	$("div").click(function()  
	{
	  
	  //$ (this).replaceWith("new content by JQuery");
	  $ (this).replaceWith("<input type='text'>");
	  //$ ("div").css("color","red");
	  
	});
	//$ ("div").replaceWith("new content by JQuery");
});
