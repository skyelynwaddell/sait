function loadPage(pageName){
    window.location.href=pageName;
}